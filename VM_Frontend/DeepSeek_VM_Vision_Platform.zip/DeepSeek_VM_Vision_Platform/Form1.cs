﻿using System;
using System.Net;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using VM.Core;



namespace DeepSeek_VM_Vision_AI_Platform
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string JanusPrompt(string imgPath,string question)
        {
            //string postUrl = "http://127.0.0.1:8000/postprompt/" + WebUtility.UrlEncode(imgPath) + "/" + WebUtility.UrlEncode(question)+"/";
            // + WebUtility.UrlEncode(imgPath) + "/" + WebUtility.UrlEncode(question);

            string postUrl = "http://127.0.0.1:8000/postprompt/" + Uri.EscapeDataString(imgPath) + "/" + Uri.EscapeDataString(question) + "/";


            // string response = postUrl.GetAsync().ReceiveString().ToString();
            //return response;


            string result = "";
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(postUrl);
            req.Method = "Get";
            //req.Headers.Add()
            try
            {
                HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
                Stream stream = resp.GetResponseStream();
                //获取内容
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    result = reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                result = ex.Message;
            }
            return result;

        }
        

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void splitter1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            // 设置对话框的过滤器，例如只显示Excel和Word文件
            openFileDialog.Filter = "图片文件(*.png;*.jpg;*bmp;*jpeg)|*.png;*.jpg;*bmp;*jpeg";

            openFileDialog.ValidateNames = true; // 验证文件名是否有效
            openFileDialog.CheckFileExists = true; // 检查文件是否存在
            openFileDialog.CheckPathExists = true; // 检查路径是否存在
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // 获取用户选择的文件路径
                string selectedFilePath = openFileDialog.FileName;
                // 可以在这里添加代码来处理文件
                ImgPathBox.Text = selectedFilePath;
                ImgShowBox.BackgroundImage = Image.FromFile(ImgPathBox.Text);
                
              
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string result = JanusPrompt(ImgPathBox.Text, QuestionBox1.Text);
            ResultBox1.Text = result;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string result = JanusPrompt(ImgPathBox.Text, "请告诉我图片中的文本内容是什么，只输出图中文本内容");
            ResultBox2.Text = result;
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void LoadSolBtn_Click(object sender, EventArgs e)
        {
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void LoadSolBtn_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            // 设置对话框的过滤器，例如只显示Excel和Word文件
            openFileDialog.Filter = "VM方案(*.sol)|*.sol";

            openFileDialog.ValidateNames = true; // 验证文件名是否有效
            openFileDialog.CheckFileExists = true; // 检查文件是否存在
            openFileDialog.CheckPathExists = true; // 检查路径是否存在
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // 获取用户选择的文件路径
                string selectedFilePath = openFileDialog.FileName;
                // 可以在这里添加代码来处理文件
                SolPathBox.Text = selectedFilePath;
                VmSolution.Load(SolPathBox.Text);

            }
            
        }

        private void ExeSolBtn_Click(object sender, EventArgs e)
        {
            VmSolution.Instance.SyncRun();
            //让输出处获取渲染结果
            VmProcedure vmProcess1 = (VmProcedure)VmSolution.Instance["流程1"];
            vmRenderControl1.ModuleSource = vmProcess1;
            //Image ocrResult = vmProcess1.ModuResult.GetOutputString("image").astStringVal[0].strValue;
           
           //string ocrNum = vmProcess1.ModuResult.GetOutputInt("out0").pIntVal[0].ToString();



        }
    }
}
