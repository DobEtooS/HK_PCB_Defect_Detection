﻿namespace DeepSeek_VM_Vision_AI_Platform
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ImgPathBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.ResultBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.QuestionDSBtn = new System.Windows.Forms.Button();
            this.QuestionBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.ResultBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.ImgShowBox = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ExeSolBtn = new System.Windows.Forms.Button();
            this.LoadSolBtn = new System.Windows.Forms.Button();
            this.SolPathBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.vmProcedureConfigControl1 = new VMControls.Winform.Release.VmProcedureConfigControl();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.vmRenderControl1 = new VMControls.Winform.Release.VmRenderControl();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImgShowBox)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControl1.Location = new System.Drawing.Point(12, 146);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1431, 929);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.ImgPathBox);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.ImgShowBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 40);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1423, 885);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "DeepSeek智慧视觉";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // ImgPathBox
            // 
            this.ImgPathBox.Location = new System.Drawing.Point(846, 607);
            this.ImgPathBox.Multiline = true;
            this.ImgPathBox.Name = "ImgPathBox";
            this.ImgPathBox.ReadOnly = true;
            this.ImgPathBox.Size = new System.Drawing.Size(507, 42);
            this.ImgPathBox.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(849, 544);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 31);
            this.label2.TabIndex = 5;
            this.label2.Text = "当前图片路径：";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControl2.Location = new System.Drawing.Point(35, 17);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(761, 808);
            this.tabControl2.TabIndex = 4;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.ResultBox1);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.QuestionDSBtn);
            this.tabPage3.Controls.Add(this.QuestionBox1);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Location = new System.Drawing.Point(4, 37);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(753, 767);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "本地大模型智慧问答";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // ResultBox1
            // 
            this.ResultBox1.Location = new System.Drawing.Point(28, 494);
            this.ResultBox1.Multiline = true;
            this.ResultBox1.Name = "ResultBox1";
            this.ResultBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ResultBox1.Size = new System.Drawing.Size(664, 214);
            this.ResultBox1.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(25, 436);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 28);
            this.label3.TabIndex = 3;
            this.label3.Text = "DeepSeek解答：";
            // 
            // QuestionDSBtn
            // 
            this.QuestionDSBtn.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.QuestionDSBtn.Location = new System.Drawing.Point(542, 356);
            this.QuestionDSBtn.Name = "QuestionDSBtn";
            this.QuestionDSBtn.Size = new System.Drawing.Size(150, 47);
            this.QuestionDSBtn.TabIndex = 2;
            this.QuestionDSBtn.Text = "确定";
            this.QuestionDSBtn.UseVisualStyleBackColor = true;
            this.QuestionDSBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // QuestionBox1
            // 
            this.QuestionBox1.Location = new System.Drawing.Point(28, 88);
            this.QuestionBox1.Multiline = true;
            this.QuestionBox1.Name = "QuestionBox1";
            this.QuestionBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.QuestionBox1.Size = new System.Drawing.Size(664, 242);
            this.QuestionBox1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(25, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "请输入您的工业问题：";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.ResultBox2);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.button3);
            this.tabPage4.Location = new System.Drawing.Point(4, 33);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(753, 771);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "DeepSeek大模型OCR";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // ResultBox2
            // 
            this.ResultBox2.Location = new System.Drawing.Point(30, 178);
            this.ResultBox2.Multiline = true;
            this.ResultBox2.Name = "ResultBox2";
            this.ResultBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ResultBox2.Size = new System.Drawing.Size(624, 557);
            this.ResultBox2.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(27, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(325, 28);
            this.label4.TabIndex = 1;
            this.label4.Text = "DeepSeek大模型OCR识别结果：";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(30, 43);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(607, 50);
            this.button3.TabIndex = 0;
            this.button3.Text = "开始OCR识别右图图片";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1109, 719);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(244, 49);
            this.button1.TabIndex = 3;
            this.button1.Text = "打开图片";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ImgShowBox
            // 
            this.ImgShowBox.BackColor = System.Drawing.Color.Silver;
            this.ImgShowBox.BackgroundImage = global::DeepSeek_VM_Vision_AI_Platform.Properties.Resources.deepseek;
            this.ImgShowBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ImgShowBox.Location = new System.Drawing.Point(846, 42);
            this.ImgShowBox.Name = "ImgShowBox";
            this.ImgShowBox.Size = new System.Drawing.Size(518, 422);
            this.ImgShowBox.TabIndex = 2;
            this.ImgShowBox.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.ExeSolBtn);
            this.tabPage2.Controls.Add(this.LoadSolBtn);
            this.tabPage2.Controls.Add(this.SolPathBox);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 40);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1423, 885);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "海康威视AI视觉";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // ExeSolBtn
            // 
            this.ExeSolBtn.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ExeSolBtn.Location = new System.Drawing.Point(1216, 134);
            this.ExeSolBtn.Name = "ExeSolBtn";
            this.ExeSolBtn.Size = new System.Drawing.Size(159, 43);
            this.ExeSolBtn.TabIndex = 6;
            this.ExeSolBtn.Text = "执行方案";
            this.ExeSolBtn.UseVisualStyleBackColor = true;
            this.ExeSolBtn.Click += new System.EventHandler(this.ExeSolBtn_Click);
            // 
            // LoadSolBtn
            // 
            this.LoadSolBtn.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LoadSolBtn.Location = new System.Drawing.Point(745, 134);
            this.LoadSolBtn.Name = "LoadSolBtn";
            this.LoadSolBtn.Size = new System.Drawing.Size(159, 43);
            this.LoadSolBtn.TabIndex = 6;
            this.LoadSolBtn.Text = "加载方案";
            this.LoadSolBtn.UseVisualStyleBackColor = true;
            this.LoadSolBtn.Click += new System.EventHandler(this.LoadSolBtn_Click_1);
            // 
            // SolPathBox
            // 
            this.SolPathBox.Location = new System.Drawing.Point(745, 86);
            this.SolPathBox.Name = "SolPathBox";
            this.SolPathBox.Size = new System.Drawing.Size(633, 39);
            this.SolPathBox.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(742, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(117, 28);
            this.label7.TabIndex = 4;
            this.label7.Text = "方案路径：";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.vmProcedureConfigControl1);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(15, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(684, 834);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "流程显示";
            // 
            // vmProcedureConfigControl1
            // 
            this.vmProcedureConfigControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.vmProcedureConfigControl1.Location = new System.Drawing.Point(3, 31);
            this.vmProcedureConfigControl1.Name = "vmProcedureConfigControl1";
            this.vmProcedureConfigControl1.Size = new System.Drawing.Size(678, 800);
            this.vmProcedureConfigControl1.TabIndex = 0;
// TODO: “”的代码生成失败，原因是出现异常“无效的基元类型: System.IntPtr。请考虑使用 CodeObjectCreateExpression。”。
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(40, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(794, 69);
            this.label5.TabIndex = 1;
            this.label5.Text = "DeepSeek海康VM智慧视觉平台";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::DeepSeek_VM_Vision_AI_Platform.Properties.Resources.DS_LOGO;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.Location = new System.Drawing.Point(1356, 33);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(74, 66);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::DeepSeek_VM_Vision_AI_Platform.Properties.Resources.HK_LOGO;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(914, 33);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(389, 66);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.vmRenderControl1);
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(742, 266);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(633, 597);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "输出";
            // 
            // vmRenderControl1
            // 
            this.vmRenderControl1.BackColor = System.Drawing.Color.Black;
            this.vmRenderControl1.CoordinateInfoVisible = true;
            this.vmRenderControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.vmRenderControl1.ImageSource = null;
            this.vmRenderControl1.Location = new System.Drawing.Point(3, 31);
            this.vmRenderControl1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.vmRenderControl1.ModuleSource = null;
            this.vmRenderControl1.Name = "vmRenderControl1";
            this.vmRenderControl1.Size = new System.Drawing.Size(627, 563);
            this.vmRenderControl1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1502, 1106);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "DeepSeek海康VM智慧视觉平台";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImgShowBox)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox ImgShowBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button QuestionDSBtn;
        private System.Windows.Forms.TextBox QuestionBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox ImgPathBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ResultBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ResultBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox groupBox1;
        private VMControls.Winform.Release.VmProcedureConfigControl vmProcedureConfigControl1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button ExeSolBtn;
        private System.Windows.Forms.Button LoadSolBtn;
        private System.Windows.Forms.TextBox SolPathBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private VMControls.Winform.Release.VmRenderControl vmRenderControl1;
    }
}

